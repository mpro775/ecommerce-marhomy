import { BadRequestException } from '@nestjs/common';
import { createQaScenarioChecksum } from './qa-scenario-checksum';

export interface NormalizedQaScenario {
  scenarioKey: string;
  title: string;
  description: string | null;
  version: string;
  checksum: string;
  sourceFile: string | null;
  metadata: Record<string, unknown>;
  snapshot: Record<string, unknown>;
  phases: NormalizedQaPhase[];
}

export interface NormalizedQaPhase {
  phaseKey: string;
  orderIndex: number;
  title: string;
  sourceTitle: string;
  goal: string | null;
  instructions: Array<Record<string, unknown>>;
  metadata: Record<string, unknown>;
  checks: NormalizedQaCheck[];
  questions: NormalizedQaQuestion[];
}

export interface NormalizedQaCheck {
  checkKey: string;
  orderIndex: number;
  text: string;
  type: string;
  required: boolean;
  weight: number | null;
  expectedResult: string | null;
  metadata: Record<string, unknown>;
}

export interface NormalizedQaQuestion {
  questionKey: string;
  orderIndex: number;
  text: string;
  type: string;
  required: boolean;
  options: Record<string, unknown> | null;
  metadata: Record<string, unknown>;
}

export function normalizeQaScenario(input: unknown): NormalizedQaScenario {
  if (!input || typeof input !== 'object') {
    throw new BadRequestException('Scenario JSON must be an object');
  }

  const source = input as Record<string, unknown>;
  const scenarioKey = requiredString(source.scenarioId, 'scenarioId');
  const title = requiredString(source.title, 'title');
  const version = requiredString(source.version, 'version');
  const phasesInput = requiredArray(source.phases, 'phases');
  const checksum = createQaScenarioChecksum(source);

  const phases = phasesInput.map((phase, index) => normalizePhase(phase, index + 1));
  assertUnique(phases.map((phase) => phase.phaseKey), 'phaseId');

  return {
    scenarioKey,
    title,
    description: typeof source.description === 'string' ? source.description : null,
    version,
    checksum,
    sourceFile: typeof source.sourceFile === 'string' ? source.sourceFile : null,
    metadata: {
      slug: source.slug ?? null,
      codePrefix: source.codePrefix ?? null,
      language: source.language ?? null,
      direction: source.direction ?? null,
      status: source.status ?? null,
      tags: source.tags ?? [],
      estimatedDurationMinutes: source.estimatedDurationMinutes ?? null,
      preconditions: source.preconditions ?? [],
      testData: source.testData ?? [],
      sourceMetadata: source.metadata ?? {},
      sourceChecksum:
        typeof (source.metadata as Record<string, unknown> | undefined)?.checksum === 'string'
          ? ((source.metadata as Record<string, unknown>).checksum as string)
          : null,
    },
    snapshot: source,
    phases,
  };
}

function normalizePhase(input: unknown, fallbackOrder: number): NormalizedQaPhase {
  if (!input || typeof input !== 'object') {
    throw new BadRequestException('Phase must be an object');
  }
  const source = input as Record<string, unknown>;
  const checks = optionalArray(source.checks).map((check, index) => normalizeCheck(check, index + 1));
  const questions = optionalArray(source.questions).map((question, index) =>
    normalizeQuestion(question, index + 1),
  );
  assertUnique(checks.map((check) => check.checkKey), 'checkId');
  assertUnique(questions.map((question) => question.questionKey), 'questionId');

  return {
    phaseKey: requiredString(source.phaseId, 'phaseId'),
    orderIndex: typeof source.order === 'number' ? source.order : fallbackOrder,
    title: requiredString(source.title, 'phase.title'),
    sourceTitle: typeof source.sourceTitle === 'string' ? source.sourceTitle : requiredString(source.title, 'phase.title'),
    goal: typeof source.objective === 'string' ? source.objective : null,
    instructions: optionalArray(source.instructions).filter(isRecord),
    metadata: {
      notes: source.notes ?? [],
      testData: source.testData ?? [],
    },
    checks,
    questions,
  };
}

function normalizeCheck(input: unknown, fallbackOrder: number): NormalizedQaCheck {
  if (!input || typeof input !== 'object') {
    throw new BadRequestException('Check must be an object');
  }
  const source = input as Record<string, unknown>;
  return {
    checkKey: requiredString(source.checkId, 'checkId'),
    orderIndex: typeof source.order === 'number' ? source.order : fallbackOrder,
    text: requiredString(source.text, 'check.text'),
    type: typeof source.type === 'string' ? source.type : 'status',
    required: typeof source.required === 'boolean' ? source.required : true,
    weight: typeof source.weight === 'number' ? source.weight : null,
    expectedResult: typeof source.expectedResult === 'string' ? source.expectedResult : null,
    metadata: {
      allowAttachment: source.allowAttachment ?? true,
      allowIssue: source.allowIssue ?? true,
    },
  };
}

function normalizeQuestion(input: unknown, fallbackOrder: number): NormalizedQaQuestion {
  if (!input || typeof input !== 'object') {
    throw new BadRequestException('Question must be an object');
  }
  const source = input as Record<string, unknown>;
  return {
    questionKey: requiredString(source.questionId, 'questionId'),
    orderIndex: typeof source.order === 'number' ? source.order : fallbackOrder,
    text: requiredString(source.text, 'question.text'),
    type: typeof source.type === 'string' ? source.type : 'textarea',
    required: typeof source.required === 'boolean' ? source.required : false,
    options: isRecord(source.options) ? source.options : null,
    metadata: {},
  };
}

function requiredString(value: unknown, field: string): string {
  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new BadRequestException(`Scenario field ${field} is required`);
  }
  return value.trim();
}

function requiredArray(value: unknown, field: string): unknown[] {
  if (!Array.isArray(value) || value.length === 0) {
    throw new BadRequestException(`Scenario field ${field} must be a non-empty array`);
  }
  return value;
}

function optionalArray(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function assertUnique(values: string[], label: string): void {
  const seen = new Set<string>();
  for (const value of values) {
    if (seen.has(value)) {
      throw new BadRequestException(`Duplicate ${label}: ${value}`);
    }
    seen.add(value);
  }
}
