import { IsBoolean, IsObject, IsOptional } from 'class-validator';

export class ImportScenarioDto {
  @IsOptional()
  @IsObject()
  scenario?: Record<string, unknown>;

  @IsOptional()
  @IsBoolean()
  publish?: boolean;
}
